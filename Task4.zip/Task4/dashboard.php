<?php
session_start();

// Check if user is logged in and is an admin
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    echo "Access denied. Admins only.";
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial;
            background-color: #f4f4f4;
            padding: 40px;
        }
        .box {
            background: white;
            padding: 25px;
            border-radius: 10px;
            max-width: 500px;
            margin: auto;
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.15);
        }
        a {
            color: #6a1b9a;
            text-decoration: none;
            font-weight: bold;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="box">
    <h2>Welcome to the Dashboard</h2>
    <p>You are logged in as: <strong><?php echo $_SESSION['role']; ?></strong></p>
    <p>This is admin content only.</p>
    <a href="logout.php">Logout</a>
</div>
</body>
</html>