<footer>
    <hr>
    <p style="text-align:center;">&copy; 2025 My Internship Project</p>
</footer>
</body>
</html>