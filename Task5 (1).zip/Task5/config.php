<?php
$servername = "localhost";
$username = "root";
$password = "";    // your database password, often empty for XAMPP / WAMP
$dbname = "final project";  // your database name

// Create a new connection object
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start session for login, authentication, etc.

// Optional: Set character set to UTF-8
$conn->set_charset("utf8");
?>