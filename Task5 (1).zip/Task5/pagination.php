<?php
include 'config.php';

// Set how many records you want per page
$limit = 5;

// Get current page number from URL, default is 1
$page = isset($_GET['page']) ? $_GET['page'] : 1;

// Calculate offset
$offset = ($page - 1) * $limit;

// Fetch records with LIMIT and OFFSET
$sql = "SELECT * FROM users LIMIT $offset, $limit";
$result = $conn->query($sql);

// Display records
while($row = $result->fetch_assoc()) {
    echo $row['id'] . ". " . $row['name'] . " - " . $row['email'] . "<br>";
}

// Count total records
$res = $conn->query("SELECT COUNT(id) AS total FROM users");
$row = $res->fetch_assoc();
$total_records = $row['total'];

// Calculate total pages
$total_pages = ceil($total_records / $limit);

// Generate page links
for($i = 1; $i <= $total_pages; $i++){
    echo "<a href='pagination.php?page=$i'>$i</a> ";
}
?>