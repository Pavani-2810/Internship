<?php
session_start();

// ✅ Allow only if user is logged in AND role is admin or editor
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'editor'])) {
    echo "<h3>Access Denied ❌</h3><p>You do not have permission to view this page.</p>";
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Website Content</title>
    <style>
        body {
            font-family: Arial;
            padding: 30px;
            background-color: #f0f0f0;
        }

        .box {
            background-color: #fff;
            max-width: 600px;
            padding: 20px;
            margin: auto;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }

        textarea {
            width: 100%;
            height: 150px;
            padding: 10px;
            margin-top: 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 16px;
        }

        button {
            margin-top: 15px;
            padding: 10px 20px;
            background-color: #007bff;
            border: none;
            color: white;
            font-size: 16px;
            border-radius: 6px;
            cursor: pointer;
        }
    </style>
</head>
<body>

<div class="box">
    <h2>Edit Website Content</h2>
    <p>Welcome, <strong><?php echo $_SESSION['username']; ?></strong> (<?php echo $_SESSION['role']; ?>)</p>

    <form method="post">
        <label>Update Page Content:</label><br>
        <textarea name="content" required placeholder="Write something..."></textarea><br>
        <button type="submit">Save Changes</button>
    </form>
</div>

</body>
</html>