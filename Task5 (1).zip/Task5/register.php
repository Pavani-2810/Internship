<?php
include 'database.php';

$success = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);
    $role = $_POST["role"];

    if (strlen($username) < 3) {
        $error = "⚠️ Username must be at least 3 characters.";
    } elseif (strlen($password) < 6) {
        $error = "⚠️ Password must be at least 6 characters.";
    } else {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $hashedPassword, $role);

        if ($stmt->execute()) {
            $success = "✅ Registered successfully!";
        } else {
            $error = "❌ Registration failed: " . $stmt->error;
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Registration</title>
    <style>
        body {
            font-family: Arial;
            background-color: #f4f4f4;
            padding: 30px;
        }

        .container {
            background-color: #fff;
            padding: 25px;
            max-width: 500px;
            margin: auto;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        label {
            font-weight: bold;
        }

        input, select, button {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            margin-bottom: 15px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        button {
            background-color: #28a745;
            color: white;
            font-weight: bold;
            border: none;
            cursor: pointer;
        }

        .message {
            text-align: center;
            font-weight: bold;
        }

        .success {
            color: green;
        }

        .error {
            color: red;
        }
    </style>
    <script>
        function validateForm() {
            let username = document.forms["regForm"]["username"].value;
            let password = document.forms["regForm"]["password"].value;

            if (username.length < 3) {
                alert("Username must be at least 3 characters.");
                return false;
            }

            if (password.length < 6) {
                alert("Password must be at least 6 characters.");
                return false;
            }

            return true;
        }
    </script>
</head>
<body>

<div class="container">
    <h2>Register New User</h2>

    <!-- Show Success or Error -->
    <?php
    if (!empty($success)) echo "<p class='message success'>$success</p>";
    if (!empty($error)) echo "<p class='message error'>$error</p>";
    ?>

    <form name="regForm" method="POST" onsubmit="return validateForm();">
        <label>Username:</label>
        <input type="text" name="username" required>

        <label>Password:</label>
        <input type="password" name="password" required>

        <label>Role:</label>
        <select name="role" required>
            <option value="user">User</option>
            <option value="editor">Editor</option>
            <option value="admin">Admin</option>
        </select>

        <button type="submit">Register</button>
    </form>
</div>

</body>
</html>