<?php
session_start();
if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Final Project</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
    <h2>My Project Dashboard</h2>
    <nav>
        <a href="view.php">Home</a> |
        <a href="add.php">Add Product</a> |
        <a href="logout.php">Logout</a>
    </nav>
    <hr>
</header>