<?php
$host = 'localhost';            // or 127.0.0.1
$user = 'root';                 
$pass = '';                     
$db='secure_app';   

// Create connection
$conn = mysqli_connect($host, $user, $pass, $db);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Optional: echo "Connected successfully";
?>