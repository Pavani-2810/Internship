<?php include 'header.php'; ?>
<?php include 'config.php'; ?>

<?php
$search = isset($_GET['search']) ? $_GET['search'] : '';
$limit = 5;
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$start_from = ($page-1) * $limit;

$sql = "SELECT * FROM products WHERE name LIKE ? LIMIT ?, ?";
$stmt = $conn->prepare($sql);
$like = "%$search%";
$stmt->bind_param("sii", $like, $start_from, $limit);
$stmt->execute();
$result = $stmt->get_result();
?>

<h2>Product List</h2>

<form method="GET" action="">
    <input type="text" name="search" placeholder="Search by name" value="<?= htmlspecialchars($search) ?>">
    <button type="submit">Search</button>
</form>
<br>

<table border="1" cellpadding="10" cellspacing="0">
<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Price</th>
    <th>Actions</th>
</tr>
<?php while($row = $result->fetch_assoc()) { ?>
<tr>
    <td><?= $row['id'] ?></td>
    <td><?= htmlspecialchars($row['name']) ?></td>
    <td><?= $row['price'] ?></td>
    <td>
        <a href="edit.php?id=<?= $row['id'] ?>">Edit</a> | 
        <a href="delete.php?id=<?= $row['id'] ?>" onclick="return confirmDelete()">Delete</a>
    </td>
</tr>
<?php } ?>
</table>

<?php
// pagination links
$psql = "SELECT COUNT(*) as total FROM products WHERE name LIKE ?";
$pstmt = $conn->prepare($psql);
$pstmt->bind_param("s", $like);
$pstmt->execute();
$ptotal = $pstmt->get_result()->fetch_assoc()['total'];
$total_pages = ceil($ptotal / $limit);

echo "<br>Pages: ";
for($i=1; $i<=$total_pages; $i++){
    echo "<a href='view.php?page=$i&search=".urlencode($search)."'>$i</a> ";
}
?>

<?php include 'footer.php'; ?>